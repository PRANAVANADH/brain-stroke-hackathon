// Dummy functions for button clicks
function showProjectDetails() {
    const modal = document.getElementById('projectDetailsModal');
    modal.style.display = 'block';
}

function closeProjectDetails() {
    const modal = document.getElementById('projectDetailsModal');
    modal.style.display = 'none';
}

function showURLRedirect() {
    const modal = document.getElementById('urlRedirectModal');
    modal.style.display = 'block';
    document.getElementById('redirectUrl').value = ''; // Clear previous input
    document.getElementById('urlErrorMessage').style.display = 'none'; // Clear error message
}

function redirectToURL() {
    const urlInput = document.getElementById('redirectUrl').value;
    const errorMessage = document.getElementById('urlErrorMessage');
    const urlPattern = /^(https?:\/\/[^\s$.?#].[^\s]*)$/i; // Basic URL validation

    if (urlPattern.test(urlInput)) {
        errorMessage.style.display = 'none';
        window.location.href = urlInput; // Redirect to the entered URL
    } else {
        errorMessage.textContent = 'Please enter a valid URL (e.g., https://colab.research.google.com/...';
        errorMessage.style.display = 'block';
    }
}

function closeURLRedirect() {
    const modal = document.getElementById('urlRedirectModal');
    modal.style.display = 'none';
}

function showAboutUs() {
    const modal = document.getElementById('aboutModal');
    modal.style.display = 'block';
}

function closeAboutUs() {
    const modal = document.getElementById('aboutModal');
    modal.style.display = 'none';
}

function logout() {
    window.location.href = 'index.html'; // Redirect to login page
}

// Add animation for page load
window.addEventListener('load', () => {
    document.querySelector('header').style.animation = 'slideDown 0.5s ease-out';
    document.querySelector('.hero-section').style.animation = 'fadeIn 0.8s ease-in';
    document.querySelector('.stroke-info').style.animation = 'fadeIn 0.8s ease-in';
    document.querySelector('.bottom-nav').style.animation = 'slideUp 0.5s ease-out';
    document.querySelector('footer').style.animation = 'slideUp 0.5s ease-out';
    document.querySelector('.logout-btn').style.animation = 'fadeIn 0.8s ease-in';
});