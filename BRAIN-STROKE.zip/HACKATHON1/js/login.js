document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('errorMessage');
    const submitBtn = document.querySelector('.submit-btn');

    // Add loading animation
    submitBtn.textContent = 'Logging in...';
    submitBtn.style.animation = 'none';
    submitBtn.style.background = '#e6c200';

    setTimeout(() => {  // Simulate server delay
        if (email === 'provider@braincheck.com' && password === 'securepass123') {  // Dummy credentials
            errorMessage.style.display = 'none';
            // Add transition animation before redirect
            document.querySelector('.login-container').style.animation = 'fadeOut 0.5s ease forwards';
            setTimeout(() => {
                window.location.href = 'dashboard.html';  // Redirect to dashboard page
            }, 500);
        } else {
            errorMessage.textContent = 'Invalid email or password';
            errorMessage.style.display = 'block';
            submitBtn.textContent = 'Submit';
            submitBtn.style.animation = 'pulse 2s infinite ease-in-out';
        }
    }, 1000);
});

// Add animation for page load
window.addEventListener('load', () => {
    document.querySelector('.login-container').style.animation = 'fadeIn 0.8s ease-in';
});